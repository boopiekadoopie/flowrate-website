import { useRef, useEffect, useState } from 'react';

interface RevealLayerProps {
  image: string;
  cursorX: number;
  cursorY: number;
}

export function RevealLayer({ image, cursorX, cursorY }: RevealLayerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [maskUrl, setMaskUrl] = useState<string>('');
  const [dimensions, setDimensions] = useState({ width: 1920, height: 1080 });

  // Monitor container size dynamically using ResizeObserver
  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      setDimensions({ width, height });
    });

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Recalculate spotlight mask when dimensions or cursor position updates
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas with transparency (alpha = 0)
    ctx.clearRect(0, 0, dimensions.width, dimensions.height);

    const SPOTLIGHT_R = 260;

    // Only draw the reveal spotlight mask when coordinates are valid
    if (cursorX !== -999 && cursorY !== -999) {
      const grad = ctx.createRadialGradient(cursorX, cursorY, 0, cursorX, cursorY, SPOTLIGHT_R);
      grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
      grad.addColorStop(0.4, 'rgba(255, 255, 255, 1)');
      grad.addColorStop(0.6, 'rgba(255, 255, 255, 0.75)');
      grad.addColorStop(0.75, 'rgba(255, 255, 255, 0.4)');
      grad.addColorStop(0.88, 'rgba(255, 255, 255, 0.12)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);
    }

    try {
      const url = canvas.toDataURL('image/png');
      setMaskUrl(url);
    } catch (e) {
      console.error('Failed to generate spotlight mask data URL:', e);
    }
  }, [cursorX, cursorY, dimensions]);

  return (
    <div
      ref={containerRef}
      id="reveal-container"
      className="absolute inset-0 z-30 pointer-events-none select-none overflow-hidden"
    >
      {/* Hidden Canvas used to rasterize the radial gradient mask */}
      <canvas
        ref={canvasRef}
        id="spotlight-mask-canvas"
        width={dimensions.width}
        height={dimensions.height}
        className="hidden"
      />

      {/* Reveal image layer with CSS mask applied */}
      <div
        id="reveal-layer-masked"
        className="absolute inset-0 bg-center bg-cover bg-no-repeat transition-opacity duration-300"
        style={{
          backgroundImage: `url(${image})`,
          maskImage: maskUrl ? `url(${maskUrl})` : 'none',
          WebkitMaskImage: maskUrl ? `url(${maskUrl})` : 'none',
          maskRepeat: 'no-repeat',
          WebkitMaskRepeat: 'no-repeat',
          maskSize: '100% 100%',
          WebkitMaskSize: '100% 100%',
        }}
      />
    </div>
  );
}
