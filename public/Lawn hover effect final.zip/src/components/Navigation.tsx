import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, ExternalLink } from 'lucide-react';

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = ['Course', 'Field Guides', 'Geology', 'Plans', 'Live Tour'];

  return (
    <>
      {/* Primary Fixed Nav Bar */}
      <nav
        id="main-navigation"
        className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-between p-4 sm:p-5 transition-all duration-300 bg-gradient-to-b from-black/50 via-black/20 to-transparent"
      >
        {/* Left: Brand logo & wordmark */}
        <div id="nav-brand" className="flex items-center gap-2.5 group cursor-pointer">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md overflow-hidden group-hover:border-white/20 transition-all duration-300">
            {/* Strata layer SVG logo */}
            <svg
              className="w-5 h-5 text-white/90 group-hover:text-white group-hover:scale-105 transition-transform duration-300"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 2L2 9L12 16L22 9L12 2Z"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M2 13L12 20L22 13"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M2 17L12 22L22 17"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
          <span className="text-white text-2xl font-playfair italic tracking-tight select-none">
            Lithos
          </span>
        </div>

        {/* Center: Glassmorphism Menu Pill (md+ only) */}
        <div
          id="nav-center-pill"
          className="hidden md:flex items-center gap-1 bg-white/5 backdrop-blur-md px-2 py-1.5 rounded-full border border-white/10 shadow-lg shadow-black/20"
        >
          {menuItems.map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
              className="text-white/70 hover:text-white hover:bg-white/10 text-xs font-medium px-4 py-2 rounded-full transition-all duration-200"
            >
              {item}
            </a>
          ))}
        </div>

        {/* Right: Actions */}
        <div id="nav-right" className="flex items-center gap-3">
          {/* Sign Up button (md+ only) */}
          <button className="hidden md:flex items-center gap-1.5 bg-white hover:bg-neutral-100 text-black text-xs font-semibold px-5 py-2.5 rounded-full transition-all duration-200 hover:scale-[1.03] active:scale-95 shadow-md shadow-black/10 cursor-pointer">
            Sign Up
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Hamburger Menu (Mobile/Tablet only) */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex md:hidden items-center justify-center w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-white/90 active:scale-95 transition-all cursor-pointer"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Navigation Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            id="mobile-nav-overlay"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-0 z-[90] bg-black/95 backdrop-blur-lg md:hidden flex flex-col justify-between p-6 pt-24"
          >
            {/* Links */}
            <div id="mobile-menu-links" className="flex flex-col gap-6 pt-6">
              <span className="text-xs font-semibold text-white/40 tracking-wider uppercase pl-2">
                Navigation
              </span>
              <div className="flex flex-col gap-1">
                {menuItems.map((item, index) => (
                  <motion.a
                    key={item}
                    href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                    onClick={() => setMobileMenuOpen(false)}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 + 0.1, duration: 0.3 }}
                    className="flex items-center justify-between text-white/80 hover:text-white text-xl font-medium px-3 py-3 rounded-xl hover:bg-white/5 transition-all"
                  >
                    {item}
                    <ExternalLink className="w-4 h-4 text-white/40" />
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Bottom Panel */}
            <div id="mobile-menu-bottom" className="flex flex-col gap-4 pb-8">
              <div className="h-[1px] bg-white/10 w-full mb-2" />
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 bg-[#e8702a] hover:bg-[#d2611f] text-white py-4 rounded-xl font-medium transition-all"
              >
                Sign Up Now
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-xs text-white/40">
                Explore the subterranean stories with Lithos.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
